library(testthat)
library(ggthemes)

test_check("ggthemes")
